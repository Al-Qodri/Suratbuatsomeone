// Messages sequence
const messages = [
    "Hai! Aku punya sesuatu yang spesial untuk kamu...",
    "Aku sudah lama ingin mengatakan ini...",
    "Setiap kali melihatmu, jantungku berdebar...",
    "Kamu membuat hariku lebih cerah dan malamku lebih hangat...",
    "Aku tidak bisa membayangkan hidup tanpamu...",
    "Jadi ini pertanyaan besarnya..."
];

let currentMessageIndex = 0;
const noButtonTexts = [
    "Yakin?",
    "Pikir lagi!",
    "Benar-benar yakin?",
    "Jangan begitu dong!",
    "Kesempatan terakhir!",
    "Kamu menyakiti hatiku  💔",
    "Tolong pertimbangkan lagi!"
]; // Menutup array dengan benar

let noButtonClickCount = 0;

// DOM elements
const initialCard = document.getElementById('initial-card');
const messageCard = document.getElementById('message-card');
const questionCard = document.getElementById('question-card');
const finalCard = document.getElementById('final-card');
const messageText = document.getElementById('message-text');
const okButton = document.getElementById('ok-button');
const yesButton = document.getElementById('yes-button');
const noButton = document.getElementById('no-button');
const heartsContainer = document.getElementById('hearts-container');

// Open envelope animation
function openEnvelope() {
    const envelope = document.querySelector('.envelope');
    envelope.classList.add('open'); // Menutup tanda kurung

    setTimeout(() => {
        initialCard.classList.add('hidden');
        messageCard.classList.remove('hidden');
        animateMessage();
    }, 800);
}

// Animate message text
function animateMessage() {
    messageText.style.opacity = 0;

    setTimeout(() => {
        messageText.textContent = messages[currentMessageIndex];
        messageText.style.opacity = 1;
    }, 300);
} // Menutup fungsi animateMessage

// Create floating hearts
function createHearts() {
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            const heart = document.createElement('div');
            heart.innerHTML = '<i class="fas fa-heart text-pink-500 floating"></i>';
            heart.className = 'confetti';
            heart.style.left = Math.random() * 100 + 'vw';
            heart.style.top = -20 + 'px';
            heart.style.fontSize = Math.random() * 20 + 10 + 'px';
            heart.style.opacity = Math.random() * 0.5 + 0.5;
            heart.style.animationDuration = Math.random() * 3 + 2 + 's';
            heartsContainer.appendChild(heart);
            
            // Animate heart falling
            setTimeout(() => {
                heart.style.top = '100vh';
                heart.style.transform = `rotate(${Math.random() * 360}deg)`;
            }, 10);
            
            // Remove heart after animation
            setTimeout(() => {
                heart.remove();
            }, 5000);
        }, i * 100);
    }
}

// Event listeners
okButton.addEventListener('click', () => {
    currentMessageIndex++;
    
    if (currentMessageIndex < messages.length) {
        animateMessage();
        
        // Shake button playfully
        okButton.classList.add('animate-bounce');
        setTimeout(() => {
            okButton.classList.remove('animate-bounce');
        }, 1000);
    } else {
        messageCard.classList.add('hidden');
        questionCard.classList.remove('hidden');
    }
});

yesButton.addEventListener('click', () => {
    questionCard.classList.add('hidden');
    finalCard.classList.remove('hidden');
    createHearts();
    
    // Keep creating hearts periodically
    setInterval(createHearts, 3000);
});

noButton.addEventListener('click', (e) => {
    if (noButtonClickCount < noButtonTexts.length) {
        noButton.textContent = noButtonTexts[noButtonClickCount];
        noButtonClickCount++;
        
        // Move button randomly
        const x = Math.random() * 200 - 100;
        const y = Math.random() * 200 - 100;
        noButton.style.transform = `translate(${x}px, ${y}px)`;
        
        // Make yes button bigger
        yesButton.style.transform = `scale(${1 + noButtonClickCount * 0.1})`;
    } else {
        // If they keep clicking no, just pretend they said yes
        questionCard.classList.add('hidden');
        finalCard.classList.remove('hidden');
        createHearts();
    }
});

// Make no button harder to click as attempts increase
noButton.addEventListener('mouseover', () => {
    if (noButtonClickCount > 0) {
        const x = Math.random() * 200 - 100;
        const y = Math.random() * 200 - 100;
        noButton.style.transform = `translate(${x}px, ${y}px)`;
    }
});
